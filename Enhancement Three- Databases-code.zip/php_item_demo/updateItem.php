<?php

require './Service.php';

$service = new Service();

if ($_SERVER["REQUEST_METHOD"] == "POST"){
    $result = $service->updateItem(); 
}
?>

<!DOCTYPE html>
<html>
<head>
<title> Update ITEM </title>
    </head>
    <!-- add link to index -->
    <a href="index.php">Home</a>
    <body>
        <form method="post">
        <fieldset>
            <legend> Update ITEM</legend>

            <input type="number" name="id" placeholder="1" ></br>
            <input type="text" name="name" placeholder="Name" ></br>

            <input type="float" name="price" placeholder="price" ></br>

            <input id="button" type="submit" name="submit">
        </fieldset>
        <!-- <?= htmlspecialchars($result); ?> -->
    </body>

</html>