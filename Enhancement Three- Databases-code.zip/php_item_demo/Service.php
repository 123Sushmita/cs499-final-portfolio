<?php

require './Database.php';
require './Item.php';

class Service
{

    function fetchAllItems()
    {
        $dbObject = new Database();
        $dbConnection = $dbObject->getDatabaseConnection();
        $sql = "SELECT * FROM item";
        $stmt = $dbConnection->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_CLASS, 'Item');
        if ($stmt->execute()) {
            return $stmt->fetchAll();
        } else {
            return 'Failed';
        }
    }

    function addStudent()
    {
        $name = $_POST['name'];
        $math = $_POST['math'];

        $dbObject = new Database();
        $dbConnection = $dbObject->getDatabaseConnection();

        $sql = "INSERT INTO students (`name`,`math`) VALUES (?,?)";

        $stmt = $dbConnection->prepare($sql);
        //var_dump($stmt);
        if ($stmt->execute([$name, $math])) {
            // The primary key value will be auto-incremented by the database
        } else {
            return 'Failed';
        }
    }

    function addItem()
    {
        $name = $_POST['name'];
        $price = $_POST['price'];
        $id = $_POST['id'];

        $dbObject = new Database();
        $dbConnection = $dbObject->getDatabaseConnection();
        $sql = "INSERT INTO item (`Iid`, `Iname`, `Sprice`) VALUES (?,?,?)";
        $stmt = $dbConnection->prepare($sql);

        if ($this->itemExists($id)) {
            echo "<script>alert('Item already exists with same ID');</script>";
            return 'Failed';
        }
   
        try {
            $stmt->execute([$id, $name, $price]);
            return 'Success';
        } catch (PDOException $e) {
            // show alert message saying problem happened please try again
            echo "<script>alert('Problem adding the item');</script>";


            return 'Failed';
        }
    }
    function deleteItem()
    {
        if (isset($_POST['exit'])) {
            header("Location: http://localhost/php_school_demo/menu.php");
        }
        $id = $_POST['id'];

        if(!$this->itemExists($id)){
            echo "<script>alert('Item does not exist');</script>";
            return 'Failed';
        }

        $dbObject = new Database();
        $dbConnection = $dbObject->getDatabaseConnection();

        $sql = "DELETE FROM item WHERE Iid=" . $id;

        try {
            $stmt = $dbConnection->query($sql);
            echo "<script>alert('Item deleted successfully');</script>";
        } catch (PDOException $e) {
            // show alert message saying problem happened please try again
            echo "<script>alert('Problem deleting the item');</script>";
            $message = $e->getMessage();
            echo $message;
            return 'Failed';
        }
    }
    function updateItem()
    {
        $id = $_POST['id'];
        $name = $_POST['name'];
        $price = $_POST['price'];

        if(!$this->itemExists($id)){
            echo "<script>alert('Item does not exist');</script>";
            return 'Failed';
        }

        $dbObject = new Database();
        $dbConnection = $dbObject->getDatabaseConnection();
        $sql = "UPDATE item SET Iname='" . $name . "', Sprice=" . $price . " WHERE Iid=" . $id;
        // echo $sql;
        try{
        $stmt = $dbConnection->query($sql);
        echo "<script>alert('Item updated successfully');</script>";
        
        } catch (PDOException $e) {
            // show alert message saying problem happened please try again
            echo "<script>alert('Problem updating the item');</script>";
            return 'Failed';
        }
    }

    function itemExists($id)
    {
        $dbObject = new Database();
        $dbConnection = $dbObject->getDatabaseConnection();
        $sql = "SELECT * FROM item WHERE Iid=" . $id;
        $stmt = $dbConnection->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_CLASS, 'Item');
        if ($stmt->execute()) {
            $result = $stmt->fetchAll();
            if (count($result) > 0) {
                return true;
            } else {
                return false;
            }
        } else {
            return 'Failed';
        }
    }
}
