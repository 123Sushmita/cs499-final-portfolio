CREATE SCHEMA final_project;
DROP TABLE IF EXISTS `CONTRACT`;
CREATE TABLE `CONTRACT` (
  `dId` int DEFAULT NULL,
  `ctId` int NOT NULL,
  `Sdate` date DEFAULT NULL,
  `Ctime` time DEFAULT NULL,
  `Cname` varchar(255) DEFAULT NULL,
  KEY `dId` (`dId`),
  CONSTRAINT `contract_ibfk_1` FOREIGN KEY (`dId`) REFERENCES `DEALER` (`dId`)
);
DROP TABLE IF EXISTS `CUSTOMER`;
CREATE TABLE `CUSTOMER` (
  `cId` int NOT NULL,
  `Cname` varchar(255) DEFAULT NULL,
  `Street` varchar(255) DEFAULT NULL,
  `City` varchar(100) DEFAULT NULL,
  `StateAb` char(2) DEFAULT NULL,
  `Zipcode` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`cId`)
);
DROP TABLE IF EXISTS `DEALER`;
CREATE TABLE `DEALER` (
  `dId` int NOT NULL,
  `Dname` varchar(255) DEFAULT NULL,
  `Street` varchar(255) DEFAULT NULL,
  `City` varchar(100) DEFAULT NULL,
  `StateAb` char(2) DEFAULT NULL,
  `Zipcode` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`dId`)
);
DROP TABLE IF EXISTS `DEALER_ITEM`;
CREATE TABLE `DEALER_ITEM` (
  `dId` int NOT NULL,
  `iId` int NOT NULL,
  `dprice` decimal(10, 2) DEFAULT NULL,
  PRIMARY KEY (`dId`, `iId`),
  KEY `iId` (`iId`),
  CONSTRAINT `dealer_item_ibfk_1` FOREIGN KEY (`dId`) REFERENCES `DEALER` (`dId`),
  CONSTRAINT `dealer_item_ibfk_2` FOREIGN KEY (`iId`) REFERENCES `ITEM` (`iId`)
);
DROP TABLE IF EXISTS `DEALER_SHOP`;
CREATE TABLE `DEALER_SHOP` (
  `dId` int NOT NULL,
  `sId` int NOT NULL,
  PRIMARY KEY (`dId`, `sId`),
  KEY `sId` (`sId`),
  CONSTRAINT `dealer_shop_ibfk_1` FOREIGN KEY (`dId`) REFERENCES `DEALER` (`dId`),
  CONSTRAINT `dealer_shop_ibfk_2` FOREIGN KEY (`sId`) REFERENCES `SHOP` (`sId`)
);
DROP TABLE IF EXISTS `EMPLOYEE`;
CREATE TABLE `EMPLOYEE` (
  `sId` int DEFAULT NULL,
  `SSN` varchar(110) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Ename` varchar(255) DEFAULT NULL,
  `Street` varchar(255) DEFAULT NULL,
  `City` varchar(100) DEFAULT NULL,
  `StateAb` char(2) DEFAULT NULL,
  `Zipcode` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Bdate` date DEFAULT NULL,
  `Sdate` date DEFAULT NULL,
  `Edate` date DEFAULT NULL,
  `Etype` varchar(50) DEFAULT NULL,
  `Level` int DEFAULT NULL,
  `Asalary` decimal(10, 2) DEFAULT NULL,
  `Agency` varchar(255) DEFAULT NULL,
  `Hsalary` decimal(10, 2) DEFAULT NULL,
  `Institute` varchar(255) DEFAULT NULL,
  `Itype` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`SSN`),
  KEY `sId` (`sId`),
  CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`sId`) REFERENCES `SHOP` (`sId`)
);
DROP TABLE IF EXISTS `ITEM`;
CREATE TABLE `ITEM` (
  `iId` int NOT NULL,
  `Iname` varchar(255) DEFAULT NULL,
  `Sprice` decimal(10, 2) DEFAULT NULL,
  PRIMARY KEY (`iId`)
);
DROP VIEW IF EXISTS `itemview`;
DROP TABLE IF EXISTS `OLDPRICE`;
CREATE TABLE `OLDPRICE` (
  `iId` int DEFAULT NULL,
  `Sprice` decimal(10, 2) DEFAULT NULL,
  `Sdate` date DEFAULT NULL,
  `Edate` date DEFAULT NULL,
  KEY `iId` (`iId`),
  CONSTRAINT `oldprice_ibfk_1` FOREIGN KEY (`iId`) REFERENCES `ITEM` (`iId`)
);
DROP TABLE IF EXISTS `ORDER`;
CREATE TABLE `ORDER` (
  `oId` int NOT NULL,
  `sId` int DEFAULT NULL,
  `Odate` date DEFAULT NULL,
  `Ddate` date DEFAULT NULL,
  `Amount` decimal(10, 2) DEFAULT NULL,
  `cId` int DEFAULT NULL,
  PRIMARY KEY (`oId`),
  KEY `sId` (`sId`),
  KEY `cId` (`cId`),
  CONSTRAINT `order_ibfk_1` FOREIGN KEY (`sId`) REFERENCES `SHOP` (`sId`),
  CONSTRAINT `order_ibfk_2` FOREIGN KEY (`cId`) REFERENCES `CUSTOMER` (`cId`)
);
DROP TABLE IF EXISTS `ORDER_ITEM`;
CREATE TABLE `ORDER_ITEM` (
  `oId` int NOT NULL,
  `sId` int DEFAULT NULL,
  `iId` int NOT NULL,
  `Icount` int DEFAULT NULL,
  PRIMARY KEY (`oId`, `iId`),
  KEY `sId` (`sId`),
  KEY `iId` (`iId`),
  CONSTRAINT `order_item_ibfk_1` FOREIGN KEY (`oId`) REFERENCES `ORDER` (`oId`),
  CONSTRAINT `order_item_ibfk_2` FOREIGN KEY (`sId`) REFERENCES `SHOP` (`sId`),
  CONSTRAINT `order_item_ibfk_3` FOREIGN KEY (`iId`) REFERENCES `ITEM` (`iId`)
);
DROP TABLE IF EXISTS `SHOP`;
CREATE TABLE `SHOP` (
  `sId` int NOT NULL,
  `Sname` varchar(255) DEFAULT NULL,
  `Street` varchar(255) DEFAULT NULL,
  `City` varchar(100) DEFAULT NULL,
  `StateAb` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ZipCode` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Sdate` date DEFAULT NULL,
  `Telno` varchar(15) DEFAULT NULL,
  `URL` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sId`)
);
DROP TABLE IF EXISTS `SHOP_CUSTOMER`;
CREATE TABLE `SHOP_CUSTOMER` (
  `sId` int NOT NULL,
  `cId` int NOT NULL,
  PRIMARY KEY (`sId`, `cId`),
  KEY `cId` (`cId`),
  CONSTRAINT `shop_customer_ibfk_1` FOREIGN KEY (`sId`) REFERENCES `SHOP` (`sId`),
  CONSTRAINT `shop_customer_ibfk_2` FOREIGN KEY (`cId`) REFERENCES `CUSTOMER` (`cId`)
);
DROP TABLE IF EXISTS `SHOP_ITEM`;
CREATE TABLE `SHOP_ITEM` (
  `sId` int NOT NULL,
  `iId` int NOT NULL,
  `Scount` int DEFAULT NULL,
  PRIMARY KEY (`sId`, `iId`),
  KEY `iId` (`iId`),
  CONSTRAINT `shop_item_ibfk_1` FOREIGN KEY (`sId`) REFERENCES `SHOP` (`sId`),
  CONSTRAINT `shop_item_ibfk_2` FOREIGN KEY (`iId`) REFERENCES `ITEM` (`iId`)
);
INSERT INTO `CONTRACT` (`dId`, `ctId`, `Sdate`, `Ctime`, `Cname`)
VALUES (2, 1, '2024-06-24', '13:00:00', 'Sprout Buddies'),
  (2, 2, '2024-07-01', '13:00:00', 'Sprout Buddies'),
  (2, 3, '2024-07-07', '13:00:00', 'Sprout Buddies'),
  (
    2,
    4,
    '2024-07-14',
    '14:00:00',
    'Sprout Sandwiches'
  ),
  (3, 1, '2024-06-25', '15:00:00', 'Sprout Greens'),
  (
    4,
    1,
    '2024-06-25',
    '16:00:00',
    'Sprout Certifications'
  ),
  (
    4,
    2,
    '2024-06-26',
    '16:00:00',
    'Sprout Certifications'
  ),
  (
    5,
    1,
    '2024-07-26',
    '13:00:00',
    'Sprout Certifications'
  ),
  (5, 2, '2024-07-26', '14:00:00', 'Sprout Buddies'),
  (
    5,
    3,
    '2024-07-26',
    '15:00:00',
    'Sprout Sandwiches'
  ),
  (
    5,
    4,
    '2024-07-26',
    '16:00:00',
    'Sprout Sandwiches'
  ),
  (5, 5, '2024-07-26', '17:00:00', 'Microgreens');
INSERT INTO `CUSTOMER` (
    `cId`,
    `Cname`,
    `Street`,
    `City`,
    `StateAb`,
    `Zipcode`
  )
VALUES (
    1,
    'Abed Abdi',
    '309 Hcounty Road',
    'Abbott',
    'TX',
    '76621-0057'
  ),
  (
    2,
    'Ismail Gulg',
    '405 E Mesquite Street',
    'Abbott',
    'TX',
    '76621-0057'
  ),
  (
    3,
    'Shakir Ali',
    '5000 Spectrum Street',
    'Addison',
    'TX',
    '75001-6880'
  ),
  (
    4,
    'Abdur Rahman',
    '1000 County Road',
    'Bradley',
    'Ok',
    '73011-0121'
  ),
  (
    5,
    'Kalipada Ghoshal',
    'Boundary Road',
    'Bradley',
    'OK',
    '73011-9600'
  ),
  (
    6,
    'Manishi Dey',
    '450 Main Street',
    'Mound City',
    'KS',
    '66056-0001'
  ),
  (
    7,
    'Nandalal Bose',
    'S Metcalf Road',
    'Louisburg',
    'KS',
    '66053-0541'
  ),
  (
    8,
    'Raja Ravi Varma',
    '2000 Forest Grove blvd',
    'Allen',
    'TX',
    '75002-8811'
  ),
  (
    9,
    'Sunil Das',
    '4000 Woodcreek Road',
    'Carrollton',
    'TX',
    '75006-1911'
  ),
  (
    10,
    'Jasper Johns',
    '2500 Sunset Ridge Drive',
    'Rockwall',
    'TX',
    '75032-0006'
  ),
  (
    11,
    'Winslow Homer',
    '11300 Juniper Lane',
    'Irving',
    'TX',
    '75039-0101'
  ),
  (
    12,
    'Albert Bierstadt',
    '400 Spruce Street',
    'Leavenworth',
    'KS',
    '66048-0001'
  ),
  (
    13,
    'Edward Hopper',
    '1500 255th Street',
    'Hillsdale',
    'KS',
    '66036-0061'
  ),
  (
    14,
    'Georgia O\'Keeffe',
    '3000 Weiss Lane',
    'Irving',
    'TX',
    '75039-0006'
  ),
  (
    15,
    'Modupeola Fadugba',
    '1112 18TH Street',
    'Plano',
    'TX',
    '75086-0019'
  ),
  (
    16,
    'Ekene Maduka',
    '15TH Street',
    'Plano',
    'TX',
    '75086-0015'
  ),
  (
    17,
    'Olu Amoda',
    '200 Travis Street',
    'Sherman',
    'TX',
    '75090-0005'
  ),
  (
    18,
    'Koki Tanaka',
    '5000 W Holiday Road',
    'Fate',
    'TX',
    '75087-2136'
  ),
  (
    19,
    'Tatsuo Miyajima',
    'Bella Ranch Drive',
    'Choctaw',
    'OK',
    '73020-0017'
  ),
  (
    20,
    'Li Chen',
    '2090 County Road',
    'Cement',
    'OK',
    '73017-1100'
  ),
  (
    21,
    'Zhan Wang',
    '1600 N Santa Fe',
    'Edmond',
    'OK',
    '73003-3661'
  );
INSERT INTO `DEALER` (
    `dId`,
    `Dname`,
    `Street`,
    `City`,
    `StateAb`,
    `Zipcode`
  )
VALUES (
    1,
    'Organic Nature',
    '1500 E Exchange Road',
    'Allen',
    'TX',
    '75002-4504'
  ),
  (
    2,
    'Green Valley',
    '1405 Julian Street',
    'Addison',
    'TX',
    '75001-4633'
  ),
  (
    3,
    'Green Mountains',
    '800 Preston Road',
    'Gunter',
    'TX',
    '75058-0001'
  ),
  (
    4,
    'Whole Foods',
    '1010 Spicewood Drive',
    'Garland',
    'TX',
    '75044-2569'
  ),
  (
    5,
    'LA Queen',
    '500 Angi Road',
    'Minden',
    'LA',
    '71055-1004'
  ),
  (
    6,
    'Castor Sprouts',
    '100 New Ramah Road',
    'Castor',
    'LA',
    '71016-2402'
  );
INSERT INTO `DEALER_ITEM` (`dId`, `iId`, `dprice`)
VALUES (1, 1, 2.00),
  (1, 2, 2.00),
  (1, 3, 1.00),
  (1, 14, 1.00),
  (2, 4, 3.00),
  (2, 5, 2.00),
  (2, 6, 2.00),
  (2, 13, 4.00),
  (3, 7, 3.00),
  (3, 8, 2.00),
  (3, 9, 2.00),
  (3, 10, 2.00),
  (4, 11, 3.00),
  (4, 12, 3.00),
  (4, 13, 2.00),
  (4, 14, 2.00),
  (5, 7, 3.00),
  (5, 11, 2.00),
  (5, 13, 5.00),
  (5, 14, 3.00),
  (6, 7, 2.00),
  (6, 8, 1.00),
  (6, 9, 3.00),
  (6, 10, 4.00);
INSERT INTO `DEALER_SHOP` (`dId`, `sId`)
VALUES (1, 1),
  (2, 1),
  (3, 1),
  (4, 1),
  (5, 1),
  (6, 1);
INSERT INTO `ITEM` (`iId`, `Iname`, `Sprice`)
VALUES (1, 'Broccoli Sprouts', 3.00),
  (2, 'Kale Sprouts', 3.00),
  (3, 'Alfalfa Sprouts', 3.00),
  (4, 'Mung Sprouts', 4.00),
  (5, 'Chickpeas Sprouts', 4.00),
  (6, 'Onion Sprouts', 4.00),
  (7, 'Soyabean Sprouts', 5.00),
  (8, 'Clover Sprouts', 3.00),
  (9, 'Kidney Beans Sprouts', 4.00),
  (10, 'Adzuki Bean Sprouts', 4.00),
  (11, 'Beet Sprouts', 5.00),
  (12, 'lolo', 22.00),
  (13, 'Radish Sprouts', 6.00),
  (14, 'Lentil Sprouts', 4.00),
  (3443, 'dfas', 12.00);
INSERT INTO `OLDPRICE` (`iId`, `Sprice`, `Sdate`, `Edate`)
VALUES (1, 3.00, '2023-01-20', NULL),
  (2, 3.00, '2023-01-20', NULL),
  (3, 1.00, '2023-01-20', '2023-01-25'),
  (3, 2.00, '2023-01-26', '2023-01-28'),
  (3, 3.00, '2023-01-29', NULL),
  (4, 4.00, '2023-01-20', NULL),
  (5, 4.00, '2023-01-20', NULL),
  (6, 4.00, '2023-01-20', NULL),
  (7, 5.00, '2023-01-20', NULL),
  (8, 3.00, '2023-01-20', NULL),
  (9, 4.00, '2023-01-20', NULL),
  (10, 4.00, '2023-01-20', NULL),
  (11, 5.00, '2023-01-20', NULL),
  (12, 5.00, '2023-01-20', NULL),
  (13, 6.00, '2023-01-20', NULL),
  (14, 2.00, '2023-01-20', '2023-01-27'),
  (14, 3.00, '2023-01-28', '2023-01-30'),
  (14, 4.00, '2023-01-31', '2023-02-10');
INSERT INTO `ORDER` (`oId`, `sId`, `Odate`, `Ddate`, `Amount`, `cId`)
VALUES (1, 1, '2023-01-20', '2023-01-21', 3.00, 1),
  (2, 1, '2023-01-20', '2023-01-21', 3.00, 2),
  (3, 1, '2023-01-20', '2023-01-21', 4.00, 3),
  (4, 1, '2023-01-20', '2023-01-21', 12.00, 4),
  (5, 1, '2023-01-20', '2023-01-21', 4.00, 5),
  (6, 1, '2023-01-20', '2023-01-21', 27.00, 6),
  (7, 1, '2023-01-20', '2023-01-21', 4.00, 7),
  (8, 1, '2023-01-20', '2023-01-21', 5.00, 8),
  (9, 1, '2023-01-20', '2023-01-21', 5.00, 9),
  (10, 1, '2023-01-20', '2023-01-21', 5.00, 10),
  (11, 1, '2023-01-20', '2023-01-21', 3.00, 11),
  (12, 1, '2023-01-25', '2023-01-26', 4.00, 12),
  (13, 1, '2023-01-25', '2023-01-26', 4.00, 13),
  (14, 1, '2023-01-25', '2023-01-26', 4.00, 14),
  (15, 1, '2023-01-25', '2023-01-26', 22.00, 2),
  (16, 1, '2023-01-25', '2023-01-26', 5.00, 5),
  (17, 1, '2023-01-25', '2023-01-26', 6.00, 9),
  (18, 1, '2023-01-30', '2023-01-31', 6.00, 15),
  (19, 1, '2023-01-30', '2023-01-31', 3.00, 16),
  (20, 1, '2023-01-30', '2023-01-31', 3.00, 17),
  (21, 1, '2023-01-30', '2023-01-31', 4.00, 2),
  (22, 1, '2023-01-30', '2023-01-31', 4.00, 9),
  (23, 1, '2023-02-05', '2023-02-06', 4.00, 18),
  (24, 1, '2023-02-05', '2023-02-06', 4.00, 19),
  (25, 1, '2023-02-05', '2023-02-06', 4.00, 20),
  (26, 1, '2023-02-10', '2023-02-11', 4.00, 21),
  (27, 1, '2023-02-12', '2023-02-13', 4.00, 21);
INSERT INTO `ORDER_ITEM` (`oId`, `sId`, `iId`, `Icount`)
VALUES (1, 1, 1, 1),
  (2, 1, 2, 1),
  (3, 1, 4, 1),
  (4, 1, 5, 1),
  (4, 1, 6, 2),
  (5, 1, 5, 1),
  (6, 1, 5, 1),
  (6, 1, 6, 2),
  (6, 1, 7, 3),
  (7, 1, 6, 1),
  (8, 1, 7, 1),
  (9, 1, 7, 1),
  (10, 1, 7, 1),
  (11, 1, 8, 1),
  (12, 1, 9, 1),
  (13, 1, 10, 1),
  (14, 1, 10, 1),
  (15, 1, 4, 1),
  (15, 1, 5, 1),
  (15, 1, 6, 1),
  (15, 1, 7, 2),
  (16, 1, 12, 1),
  (17, 1, 13, 1),
  (18, 1, 13, 1),
  (19, 1, 1, 1),
  (20, 1, 2, 1),
  (21, 1, 4, 1),
  (22, 1, 4, 1),
  (23, 1, 4, 1),
  (24, 1, 4, 1),
  (25, 1, 5, 1),
  (26, 1, 5, 1),
  (27, 1, 5, 1);
INSERT INTO `SHOP` (
    `sId`,
    `Sname`,
    `Street`,
    `City`,
    `StateAb`,
    `ZipCode`,
    `Sdate`,
    `Telno`,
    `URL`
  )
VALUES (
    1,
    'Arlington Herbal',
    '1 Cooper Street',
    'Arlington',
    'TX',
    '76019-0012',
    '2023-01-10',
    '8172721111',
    'www.ArlingtonSprouts-1.com'
  );
INSERT INTO `SHOP_CUSTOMER` (`sId`, `cId`)
VALUES (1, 1),
  (1, 2),
  (1, 3),
  (1, 4),
  (1, 5),
  (1, 6),
  (1, 7),
  (1, 8),
  (1, 9),
  (1, 10),
  (1, 11),
  (1, 12),
  (1, 13),
  (1, 14),
  (1, 15),
  (1, 16),
  (1, 17),
  (1, 18),
  (1, 19),
  (1, 20),
  (1, 21);
INSERT INTO `SHOP_ITEM` (`sId`, `iId`, `Scount`)
VALUES (1, 1, 10),
  (1, 2, 10),
  (1, 3, 10),
  (1, 4, 10),
  (1, 5, 10),
  (1, 6, 10),
  (1, 7, 10),
  (1, 8, 10),
  (1, 9, 10),
  (1, 10, 12),
  (1, 11, 13),
  (1, 12, 10),
  (1, 13, 16),
  (1, 14, 15);