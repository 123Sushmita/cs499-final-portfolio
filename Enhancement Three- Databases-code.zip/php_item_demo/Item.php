<?php


class Item{
    public int $iId;
    public float $Sprice;
    public string $Iname;
}