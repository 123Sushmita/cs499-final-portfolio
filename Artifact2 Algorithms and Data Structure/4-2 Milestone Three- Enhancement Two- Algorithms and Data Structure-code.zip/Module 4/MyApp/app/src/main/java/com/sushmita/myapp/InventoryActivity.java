package com.sushmita.myapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {

    private DBHelper dbHelper;  // Class-level dbHelper variable
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> itemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Initialize dbHelper at the class level, not locally
        dbHelper = new DBHelper(this);  // Use the class-level dbHelper

        listView = findViewById(R.id.listView);
        itemList = dbHelper.getAllInventoryItems();  // Use the class-level dbHelper to get inventory items

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, itemList);
        listView.setAdapter(adapter);

        Button addButton = findViewById(R.id.addButton);
        EditText nameEditText = findViewById(R.id.nameEditText);
        EditText quantityEditText = findViewById(R.id.quantityEditText);

        addButton.setOnClickListener(v -> {
            String name = nameEditText.getText().toString();
            int quantity = Integer.parseInt(quantityEditText.getText().toString());
            dbHelper.addInventoryItem(name, quantity);  // Use class-level dbHelper to add item
            itemList.clear();
            itemList.addAll(dbHelper.getAllInventoryItems());  // Update the list with the new items
            adapter.notifyDataSetChanged();  // Notify adapter of data changes
        });
    }
}
