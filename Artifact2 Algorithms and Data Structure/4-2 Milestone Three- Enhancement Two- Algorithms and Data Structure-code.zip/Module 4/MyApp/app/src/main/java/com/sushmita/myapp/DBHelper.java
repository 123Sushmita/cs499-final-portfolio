package com.sushmita.myapp;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "app_db";
    private static final int DATABASE_VERSION = 1;

    // Table names
    private static final String TABLE_USER = "Users";
    private static final String TABLE_INVENTORY = "InventoryItems";
    private static final String TABLE_EVENT = "EventDetails";
    private static final String TABLE_WEIGHT = "DailyWeight";

    // Column names for Users
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USER_USERNAME = "username";
    private static final String COLUMN_USER_PASSWORD = "password";

    // Column names for InventoryItems
    private static final String COLUMN_INV_ID = "id";
    private static final String COLUMN_INV_NAME = "name";
    private static final String COLUMN_INV_QUANTITY = "quantity";

    // Column names for EventDetails
    private static final String COLUMN_EVENT_ID = "event_id";
    private static final String COLUMN_EVENT_NAME = "event_name";
    private static final String COLUMN_EVENT_DATE = "event_date";
    private static final String COLUMN_EVENT_LOCATION = "event_location";

    // Column names for DailyWeight
    private static final String COLUMN_WEIGHT_ID = "record_id";
    private static final String COLUMN_WEIGHT_DATE = "date";
    private static final String COLUMN_WEIGHT_VALUE = "weight";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users table
        String createUserTable = "CREATE TABLE " + TABLE_USER + " (" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USER_USERNAME + " TEXT NOT NULL, " +
                COLUMN_USER_PASSWORD + " TEXT NOT NULL);";
        db.execSQL(createUserTable);

        // Create InventoryItems table
        String createInventoryTable = "CREATE TABLE " + TABLE_INVENTORY + " (" +
                COLUMN_INV_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_INV_NAME + " TEXT NOT NULL, " +
                COLUMN_INV_QUANTITY + " INTEGER NOT NULL);";
        db.execSQL(createInventoryTable);

        // Create EventDetails table
        String createEventTable = "CREATE TABLE " + TABLE_EVENT + " (" +
                COLUMN_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_EVENT_NAME + " TEXT NOT NULL, " +
                COLUMN_EVENT_DATE + " TEXT NOT NULL, " +
                COLUMN_EVENT_LOCATION + " TEXT NOT NULL);";
        db.execSQL(createEventTable);

        // Create DailyWeight table
        String createWeightTable = "CREATE TABLE " + TABLE_WEIGHT + " (" +
                COLUMN_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_WEIGHT_DATE + " TEXT NOT NULL, " +
                COLUMN_WEIGHT_VALUE + " DECIMAL(5,2) NOT NULL);";
        db.execSQL(createWeightTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT);
        onCreate(db);
    }

    // Register User (for registration)
    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if the username already exists
        Cursor cursor = db.query(TABLE_USER, null, COLUMN_USER_USERNAME + " = ?",
                new String[]{username}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            // Username already exists
            cursor.close();
            db.close();
            return false; // Registration failed
        }

        // Proceed with inserting the new user if the username is unique
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_USERNAME, username);
        values.put(COLUMN_USER_PASSWORD, password);

        long result = db.insert(TABLE_USER, null, values);
        db.close();

        return result != -1; // If result is -1, insert failed
    }

    // Validate User (for login)
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USER, null, COLUMN_USER_USERNAME + " = ? AND " +
                        COLUMN_USER_PASSWORD + " = ?", new String[]{username, password},
                null, null, null);

        boolean isValid = false;
        if (cursor != null) {
            isValid = cursor.moveToFirst(); // This will return true if the cursor has data
            cursor.close();
        }
        db.close();
        return isValid;
    }

    // Add Inventory Item
    public void addInventoryItem(String name, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_INV_NAME, name);
        values.put(COLUMN_INV_QUANTITY, quantity);
        db.insert(TABLE_INVENTORY, null, values);
        db.close();
    }

    // Get all Inventory Items
    public ArrayList<String> getAllInventoryItems() {
        ArrayList<String> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_INVENTORY, null, null, null, null, null, null);

        // Check if cursor is valid and contains data
        if (cursor != null && cursor.getCount() > 0) {
            cursor.moveToFirst();

            while (!cursor.isAfterLast()) {
                // Safely access column indices
                int nameIndex = cursor.getColumnIndex(COLUMN_INV_NAME);
                int quantityIndex = cursor.getColumnIndex(COLUMN_INV_QUANTITY);

                // Ensure the column indices are valid
                if (nameIndex >= 0 && quantityIndex >= 0) {
                    String item = cursor.getString(nameIndex) + " - " +
                            cursor.getInt(quantityIndex) + " pcs";
                    itemList.add(item);
                }

                cursor.moveToNext();
            }
            cursor.close();
        } else {
            Log.e("DBHelper", "No data found in inventory table.");
        }
        db.close();
        return itemList;
    }

    // Add Event Detail
    public void addEvent(String eventName, String eventDate, String eventLocation) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_NAME, eventName);
        values.put(COLUMN_EVENT_DATE, eventDate);
        values.put(COLUMN_EVENT_LOCATION, eventLocation);
        db.insert(TABLE_EVENT, null, values);
        db.close();
    }

    // Get all Events
    public ArrayList<String> getAllEvents() {
        ArrayList<String> eventList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_EVENT, null, null, null, null, null, null);

        // Check if cursor is valid and contains data
        if (cursor != null && cursor.getCount() > 0) {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                @SuppressLint("Range") String event = cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_NAME)) + " on " +
                        cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_DATE)) + " at " +
                        cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_LOCATION));
                eventList.add(event);
                cursor.moveToNext();
            }
            cursor.close();
        } else {
            Log.e("DBHelper", "No data found in events table.");
        }
        db.close();
        return eventList;
    }

    // Add Daily Weight
    public void addDailyWeight(String date, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT_DATE, date);
        values.put(COLUMN_WEIGHT_VALUE, weight);
        db.insert(TABLE_WEIGHT, null, values);
        db.close();
    }

    // Get all Daily Weights
    public ArrayList<String> getAllDailyWeights() {
        ArrayList<String> weightList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_WEIGHT, null, null, null, null, null, null);

        // Check if cursor is valid and contains data
        if (cursor != null && cursor.getCount() > 0) {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                @SuppressLint("Range") String weight = cursor.getString(cursor.getColumnIndex(COLUMN_WEIGHT_DATE)) + ": " +
                        cursor.getDouble(cursor.getColumnIndex(COLUMN_WEIGHT_VALUE)) + " kg";
                weightList.add(weight);
                cursor.moveToNext();
            }
            cursor.close();
        } else {
            Log.e("DBHelper", "No data found in daily weight table.");
        }
        db.close();
        return weightList;
    }
}
