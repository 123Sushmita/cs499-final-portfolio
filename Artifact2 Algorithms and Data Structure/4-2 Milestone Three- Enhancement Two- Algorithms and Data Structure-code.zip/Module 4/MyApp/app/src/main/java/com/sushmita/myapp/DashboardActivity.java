package com.sushmita.myapp;

import android.content.Intent;  // Missing import statement
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    private Button goToProfileButton;
    private Button goToSettingsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        try {
            // Initialize buttons
            goToProfileButton = findViewById(R.id.profile_button);
            goToSettingsButton = findViewById(R.id.settings_button);

            if (goToProfileButton == null || goToSettingsButton == null) {
                Log.e("DashboardActivity", "Buttons not found in layout!");
                return;  // Exit early to prevent crash
            }

            // Set button click listeners for Profile navigation
            goToProfileButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d("DashboardActivity", "Navigating to ProfileActivity");
                    try {
                        Intent profileIntent = new Intent(DashboardActivity.this, ProfileActivity.class);
                        startActivity(profileIntent);  // Start the ProfileActivity
                        finish(); // Optionally finish current activity
                    } catch (Exception e) {
                        Log.e("DashboardActivity", "Error navigating to ProfileActivity", e);
                    }
                }
            });

            // Set button click listeners for Settings navigation
            goToSettingsButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d("DashboardActivity", "Navigating to SettingsActivity");
                    try {
                        Intent settingsIntent = new Intent(DashboardActivity.this, SettingsActivity.class);
                        startActivity(settingsIntent); // Start the SettingsActivity
                        finish(); // Optionally finish current activity
                    } catch (Exception e) {
                        Log.e("DashboardActivity", "Error navigating to SettingsActivity", e);
                    }
                }
            });

            // Set a delay to close the activity (if desired)
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    finish(); // Close activity after 5 seconds (for demonstration)
                }
            }, 5000);

        } catch (Exception e) {
            Log.e("DashboardActivity", "Error in onCreate: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
